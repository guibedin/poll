package vote

type Service interface {
	Vote()
}
