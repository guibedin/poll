package vote

type Vote struct {
}
