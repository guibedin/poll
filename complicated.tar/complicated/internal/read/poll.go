package read

type Poll struct {
}
